import React from "react";
import "./Input.scss";

function Badges({ value }) {
  return <div className="badges-container">{value}</div>;
}

export default Badges;
