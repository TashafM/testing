export const colCurrentPartners = [
    { title: "Name", value: "name" },
    { title: "Telephone No. 1", value: "telephone1" },
    { title: "Telephone No. 2", value: "telephone2" },
    { title: "Mobile No.", value: "mobile" },
    { title: "Email", value: "email" },
    { title: "Website", value: "website" },
    { title: "Partner Type", value: "partnerType" },
    { title: "PAN No.", value: "pan" },
    { title: "GSTIN No.", value: "gstin" },
    { title: "ARN No.", value: "arn" },
  ];

  export const colPastPartners = [
    { title: "Name", value: "name" },
    { title: "Telephone No. 1", value: "telephone1" },
    { title: "Telephone No. 2", value: "telephone2" },
    { title: "Mobile No.", value: "mobile" },
    { title: "Email", value: "email" },
    { title: "Website", value: "website" },
    { title: "Partner Type", value: "partnerType" },
    { title: "PAN No.", value: "pan" },
    { title: "GSTIN No.", value: "gstin" },
    { title: "ARN No.", value: "arn" },
  ];