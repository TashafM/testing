export const dummyData = [
  { title: "First Name", value: "firstName" },
  // { title: "Last Name", value: "lastName" },
  { title: "Personal Email", value: "personalEmail" },
  { title: "Display Email", value: "displayEmail" },
  { title: "Contact No.", value: "phone" },
  { title: "Display Phone", value: "displayPhone" },
  { title: "Department", value: "department" },
  { title: "Designation", value: "designation" },
  { title: "Employee Code", value: "emp_code" },
  // { title: "Location", value: "location" },
];
