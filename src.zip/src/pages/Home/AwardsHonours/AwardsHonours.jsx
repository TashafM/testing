import React from 'react'

const AwardsHonours = () => {
  return (
    <div>
      <h1>AwardsHonours Page</h1>
    </div>
  )
}

export default AwardsHonours
