import React from 'react'

const ProductListings = () => {
  return (
    <div>
      <h1>Product Listings Come Here</h1>
    </div>
  )
}

export default ProductListings
