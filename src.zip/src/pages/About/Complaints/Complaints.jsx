import React from 'react'

function Complaints() {
    return <div>Complaints</div>
}

export default Complaints
