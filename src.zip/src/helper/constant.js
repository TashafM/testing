
export  const nameLabel =["Yes",'No']


export const Placeses = [
    { label: "Pen India", value: "Pen India" },
    { label: "Mumbai", value: "gv" },
    { label: "Chandigarh", value: "Chandigarh" },
    { label: "Delhi", value: "Delhi" },
    { label: "Goa", value: "Goa" }
];


export const Interested = [
    { label: "Printing", value: "Pen India" },
    { label: "Print Heads", value: "Print Heads" },
    { label: "Scrap", value: "Scrap" },
    { label: "Paper Panel", value: "Paper Panel" },
    { label: "Pages", value: "Pages" },
    { label: "wires", value: "Goawires" },
    { label: "Paper Sheet", value: "Paper Sheet" },
];

