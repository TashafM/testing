class Helper{

    sayHello(){

        console.log("Hello word")
    }
}

export {Helper}